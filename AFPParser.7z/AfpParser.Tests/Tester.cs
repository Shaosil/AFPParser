﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace AfpParser.Tests
{
    [TestClass]
    public class Tester
    {
        [TestMethod]
        public void Misc()
        {
        }
    }
}
